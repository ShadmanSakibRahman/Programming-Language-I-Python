user_input = input()

for index in range(len(user_input) + 1):
    print(user_input[:index])
