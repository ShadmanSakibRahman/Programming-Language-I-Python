word = input()

for index in word:
    ascii_num = ord(index)
    print("{0} : {1}".format(index, ascii_num))
