str_1 = input()
str_2 = input()

print("{}{}{}{}".format(str_2[-1], str_1[-1], str_2[0], str_1[0]))
