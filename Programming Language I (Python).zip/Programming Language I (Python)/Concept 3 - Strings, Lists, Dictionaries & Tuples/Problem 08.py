user_input = input()
ch = input()

print(user_input.replace(ch, "\n"))
