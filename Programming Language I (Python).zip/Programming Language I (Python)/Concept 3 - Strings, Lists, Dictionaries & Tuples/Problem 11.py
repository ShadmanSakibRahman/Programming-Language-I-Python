str_input = input()
num = int(input())

if num % 2 == 0:
    print(str_input * (num * 2))
else:
    print(str_input * (num * 3))
