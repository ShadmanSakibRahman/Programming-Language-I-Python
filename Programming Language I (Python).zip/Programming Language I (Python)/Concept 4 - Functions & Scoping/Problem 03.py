user_list = []
for count in range(5):
    user_input = int(input())
    user_list.append(user_input)
user_list.reverse()

for num in user_list:
    print(num)
