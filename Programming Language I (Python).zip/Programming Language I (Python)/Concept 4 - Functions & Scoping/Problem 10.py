user_list = [item[1 : len(item) - 1] for item in input().split(",") if len(item) > 2]
print(user_list)
