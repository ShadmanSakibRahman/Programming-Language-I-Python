user_list = []

for count in range(10):
    user_input = int(input())
    user_list.append(user_input)
    print("Numbers in the list: {}".format(user_list))
