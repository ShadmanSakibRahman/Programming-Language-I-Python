user_input = int(input())

if user_input % 2 == 0:
    print("The number is even")
else:
    print("The number is odd")
