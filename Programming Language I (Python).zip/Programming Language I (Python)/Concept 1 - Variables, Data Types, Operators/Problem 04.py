num_1 = float(input("Please Enter your First number: "))
num_2 = float(input("Please Enter your Second number: "))

if num_1 > num_2:
    print(num_1 - num_2)
else:
    print(num_2 - num_1)
