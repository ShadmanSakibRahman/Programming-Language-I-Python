num_1 = int(input("Please Enter your First number: "))
num_2 = int(input("Please Enter your Second number: "))

if num_1 > num_2:
    print("First is greater")
elif num_1 < num_2:
    print("Second is greater")
else:
    print("The numbers are equal")
