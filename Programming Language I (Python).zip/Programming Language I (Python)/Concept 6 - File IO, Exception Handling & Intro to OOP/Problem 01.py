def even_checker(num):
    if num % 2 == 0:
        print("Even!!")
    else:
        print("Odd!!")


# Function Call
even_checker(5)
even_checker(2)
