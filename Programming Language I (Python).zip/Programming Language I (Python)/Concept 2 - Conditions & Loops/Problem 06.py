counter = 10

while counter >= 10 and counter <= 50:
    if counter % 2 != 0:
        print(counter, end=" ")
    counter += 1
