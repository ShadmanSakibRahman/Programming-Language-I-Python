car_name = input("Please Enter the name of your favourite car: ")
number = int(input("Please Enter a number: "))

counter = 1

while counter <= number:
    print(car_name)
    counter += 1
