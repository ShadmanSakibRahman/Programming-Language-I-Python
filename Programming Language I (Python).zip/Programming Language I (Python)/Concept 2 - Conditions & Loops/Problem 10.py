total = 0
count = 0

for i in range(0, 10):
    num = int(input("Input: "))
    total += num
    print("Output:", total)
