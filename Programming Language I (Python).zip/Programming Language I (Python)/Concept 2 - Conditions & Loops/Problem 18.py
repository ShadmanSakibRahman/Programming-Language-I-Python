N = int(input())

for out_counter in range(N):
    for in_counter in range(N):
        print("+", end="")
    print()
