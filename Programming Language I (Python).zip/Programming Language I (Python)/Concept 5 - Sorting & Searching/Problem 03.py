book_info = (
    ("Best Mystery & Thriller", "The Silent Patient", 68, 821),
    ("Best Horror", "The Institute", 75, 717),
    ("Best History & Biography", "The five", 31, 783),
    ("Best Fiction", "The Testaments", 98, 291),
)

tuple_len = len(book_info)
print(f"Size of the tuple is: {tuple_len}")

for item in book_info:
    print(item)
