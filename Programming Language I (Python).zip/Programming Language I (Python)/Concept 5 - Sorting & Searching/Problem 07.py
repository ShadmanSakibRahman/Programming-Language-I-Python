# The question didn't ask me to input from the user. So, I can just use any 2 random dictionary? Right?
dict_1 = {"Harry": 15, "Draco": 8, "Nevil": 19}
dict_2 = {"Ginie": 18, "Luna": 14}

marks = {**dict_1, **dict_2}
print(marks)
